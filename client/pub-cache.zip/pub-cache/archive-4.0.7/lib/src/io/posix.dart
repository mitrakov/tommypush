export 'posix_html.dart' if (dart.library.io) 'posix_io.dart';
