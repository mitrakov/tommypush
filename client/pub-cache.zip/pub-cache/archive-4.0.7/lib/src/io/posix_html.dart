bool isPosixSupported() {
  return false;
}

void chmod(String path, String permissions) {}
