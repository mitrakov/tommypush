export '_gzip_decoder_web.dart' if (dart.library.io) '_gzip_decoder_io.dart';
