export '_zlib_decoder_web.dart' if (dart.library.io) '_zlib_decoder_io.dart';
