export '_zlib_encoder_web.dart' if (dart.library.io) '_zlib_encoder_io.dart';
