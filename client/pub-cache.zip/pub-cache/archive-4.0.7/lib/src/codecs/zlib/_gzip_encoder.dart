export '_gzip_encoder_web.dart' if (dart.library.io) '_gzip_encoder_io.dart';
