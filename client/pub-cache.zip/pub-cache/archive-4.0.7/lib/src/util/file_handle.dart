export '_file_handle_html.dart' if (dart.library.io) '_file_handle_io.dart';
