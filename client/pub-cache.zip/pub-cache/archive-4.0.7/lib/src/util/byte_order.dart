enum ByteOrder { littleEndian, bigEndian }
