enum FileAccess { closed, read, write }
