/// The type of encryption used to encrypt archive file contents.
enum EncryptionType { none, aes, zipCrypto }
