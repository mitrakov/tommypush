/// The format of the compression an [ArchiveFile] is stored with.
enum CompressionType { none, deflate, bzip2 }
