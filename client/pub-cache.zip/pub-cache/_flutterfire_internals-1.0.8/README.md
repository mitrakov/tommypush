# \_flutterfire_internals

This package is hosting Dart code shared between FlutterFire plugins. It is not
meant for public consumption.