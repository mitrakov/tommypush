// Copyright (c) 2017, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

part of breakpoint_in_parts_class;

void foo() {
  print("lalala");
}

class Foo1 {
  final foo;

  Foo1(this.foo) {
    print("hello from foo!");
  }
}

class Foo2 {
  final foo;

  Foo2(this.foo) {
    print("hello from foo!");
  }
}

class Foo3 {
  final foo;

  Foo3(this.foo) {
    print("hello from foo!");
  }
}

class Foo4 {
  final foo;

  Foo4(this.foo) {
    print("hello from foo!");
  }
}

class Foo5 {
  final foo;

  Foo5(this.foo) {
    print("hello from foo!");
  }
}

class Foo6 {
  final foo;

  Foo6(this.foo) {
    print("hello from foo!");
  }
}

class Foo7 {
  final foo;

  Foo7(this.foo) {
    print("hello from foo!");
  }
}

class Foo8 {
  final foo;

  Foo8(this.foo) {
    print("hello from foo!");
  }
}

class Foo9 {
  final foo;

  Foo9(this.foo) {
    print("hello from foo!");
  }
}

class Foo10 {
  final foo;

  Foo10(this.foo) {
    print("hello from foo!");
  }
}

var foo2 = foo() as dynamic;
