# firebase_core_web

The web implementation of `firebase_core`.

To learn more about Firebase, please visit the [Firebase website](https://firebase.google.com)

## Getting Started

To get started with FlutterFire, please [see the documentation](https://firebase.google.com/docs/flutter/setup?platform=web)
available at [https://firebase.google.com](https://firebase.google.com)

Once installed, Firebase needs to be configured for Web Installation.  Please [see the documentation](https://firebase.google.com/docs/flutter/setup?platform=web) on Web Installation
